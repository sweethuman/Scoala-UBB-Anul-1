from unittest import TestCase


class TestGradeManager(TestCase):
    def test_grades(self):
        self.fail()

    def test_get_discipline_grades(self):
        self.fail()

    def test_get_student_grades(self):
        self.fail()

    def test_add_grade(self):
        self.fail()

    def test_remove_all_discipline_grades(self):
        self.fail()

    def test_remove_all_student_grades(self):
        self.fail()
