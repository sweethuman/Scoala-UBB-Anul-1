from unittest import TestCase


class TestDisciplineManager(TestCase):
    def test_add_discipline(self):
        self.fail()

    def test_remove_discipline(self):
        self.fail()

    def test_retrieve_discipline(self):
        self.fail()

    def test_discipline_id_exists(self):
        self.fail()

    def test_last_discipline_id(self):
        self.fail()

    def test_disciplines(self):
        self.fail()
