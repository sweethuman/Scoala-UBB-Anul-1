from unittest import TestCase


class TestStudentManager(TestCase):
    def test_add_student(self):
        self.fail()

    def test_remove_student(self):
        self.fail()

    def test_retrieve_student(self):
        self.fail()

    def test_student_id_exists(self):
        self.fail()

    def test_last_student_id(self):
        self.fail()

    def test_students(self):
        self.fail()
