from typing import Protocol


class StorageProtocol(Protocol):
    def store(self, object_id: str, data):
        ...

    def retrieve(self, object_id: str) -> object:
        ...
