from .storage import StorageProtocol
