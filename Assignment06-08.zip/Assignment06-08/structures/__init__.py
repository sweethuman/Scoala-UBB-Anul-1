from .discipline import Discipline
from .student import Student
from .grade import Grade