from collections import OrderedDict
from typing import Dict
from errors import DuplicateIdError, MissingIdError
from structures.student import Student


class StudentManager:
    __students: Dict[int, Student] = OrderedDict()

    def add_student(self, student: Student):
        if self.__students.get(student.id) is not None:
            raise DuplicateIdError('Student Id already exists')
        self.__students[student.id] = student

    def remove_student(self, student_id: int):
        if self.__students.get(student_id) is None:
            raise MissingIdError('Student with given id does not exist')
        self.__students.pop(student_id)

    def retrieve_student(self, student_id: int):
        if self.__students.get(student_id) is None:
            raise MissingIdError('Student with given id does not exist')
        return self.__students[student_id]

    def student_id_exists(self, student_id):
        if self.__students.get(student_id) is None:
            return False
        return True

    @property
    def last_student_id(self):
        if len(self.__students.keys()) == 0:
            return 0
        return list(self.__students.keys())[-1]

    @property
    def students(self):
        return list(self.__students.values())
