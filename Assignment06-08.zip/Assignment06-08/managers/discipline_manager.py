from collections import OrderedDict
from typing import Dict
from structures.discipline import Discipline
from errors import DuplicateIdError, MissingIdError


class DisciplineManager:
    __disciplines: Dict[int, Discipline] = OrderedDict()

    def add_discipline(self, discipline: Discipline):
        if self.__disciplines.get(discipline.id) is not None:
            raise DuplicateIdError('Discipline Id already exists')
        self.__disciplines[discipline.id] = discipline

    def remove_discipline(self, discipline_id: int):
        if self.__disciplines.get(discipline_id) is None:
            raise MissingIdError('Discipline with given id does not exist')
        self.__disciplines.pop(discipline_id)

    def retrieve_discipline(self, discipline_id: int):
        if self.__disciplines.get(discipline_id) is None:
            raise MissingIdError('Discipline with given id does not exist')
        return self.__disciplines[discipline_id]

    def discipline_id_exists(self, discipline_id):
        if self.__disciplines.get(discipline_id) is None:
            return False
        return True

    @property
    def last_discipline_id(self):
        if len(self.__disciplines.keys()) == 0:
            return 0
        return list(self.__disciplines.keys())[-1]

    @property
    def disciplines(self):
        return list(self.__disciplines.values())
