from typing import List, Dict
from structures.grade import Grade
from managers.student_manager import StudentManager
from managers.discipline_manager import DisciplineManager
from errors import MissingIdError


class GradeManager:

    def __init__(self, student_manager: StudentManager, discipline_manager: DisciplineManager):
        self.student_manager = student_manager
        self.discipline_manager = discipline_manager

    __disciplines: Dict[int, List[Grade]] = {}
    __students: Dict[int, List[Grade]] = {}

    @property
    def grades(self):
        return [item for sublist in self.__disciplines.values() for item in sublist]

    # Raises KeyError if key doesn't exist
    def get_discipline_grades(self, discipline_id):
        return self.__disciplines[discipline_id]

    # Raises KeyError if key doesn't exist
    def get_student_grades(self, student_id):
        return self.__students[student_id]

    def add_grade(self, grade: Grade):
        if not self.student_manager.student_id_exists(grade.student_id):
            raise MissingIdError('Student with given id does not exist!')
        if not self.discipline_manager.discipline_id_exists(grade.discipline_id):
            raise MissingIdError('Discipline with given id does not exist!')
        if self.__disciplines.get(grade.discipline_id) is None:
            self.__disciplines[grade.discipline_id] = []
        if self.__students.get(grade.student_id) is None:
            self.__students[grade.student_id] = []
        self.__disciplines[grade.discipline_id].append(grade)
        self.__students[grade.student_id].append(grade)

    # TODO if the key doesn't exist it raises a KeyError
    def remove_all_discipline_grades(self, discipline_id):
        grades = self.__disciplines.pop(discipline_id)
        for x in grades:
            self.__students[x.student_id].remove(x)

    def remove_all_student_grades(self, student_id):
        grades = self.__students.pop(student_id)
        for x in grades:
            self.__disciplines[x.discipline_id].remove(x)
