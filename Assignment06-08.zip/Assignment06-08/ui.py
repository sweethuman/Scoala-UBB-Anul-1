from managers.discipline_manager import DisciplineManager
from managers.student_manager import StudentManager
from structures import Student, Discipline, Grade
from typing import List, Union
from errors import MissingIdError
from managers.grade_manager import GradeManager


class UI:
    def __init__(self, student_manager: StudentManager, discipline_manager: DisciplineManager,
                 grade_manager: GradeManager):
        self.student_manager = student_manager
        self.discipline_manager = discipline_manager
        self.grade_manager = grade_manager

    def print_menu(self):
        print('\n1. Add Student or Discipline\n'
              '2. Remove Student or Discipline\n'
              '3. Update Student or Discipline\n'
              '4. List Students or Disciplines\n'
              '5. Grade a Student at a Discipline\n'
              '6. Display grades for Discipline or Student\n')

    def selected_option(self):
        while True:
            read_input = input('Select Student(1) or Discipline(2): ')
            if read_input == '1':
                return 1
            elif read_input == '2':
                return 2
            else:
                print('Sorry. Wrong value. \n')

    def executioner(self):
        while True:
            self.print_menu()
            read_input = input('Please select an option: ')
            if read_input == '1':
                if self.selected_option() == 1:
                    student = self.read_student()
                    self.student_manager.add_student(student)
                    print('Student Added')
                else:
                    discipline = self.read_discipline()
                    self.discipline_manager.add_discipline(discipline)
                    print('Discipline Added')
            elif read_input == '2':
                if self.selected_option() == 1:
                    print('List of students')
                    self.list_students_disciplines(self.student_manager.students)
                    read_id = input('Enter Student id:')
                    try:
                        read_id = int(read_id)
                        self.student_manager.remove_student(read_id)
                        try:
                            self.grade_manager.remove_all_student_grades(read_id)
                        except KeyError:
                            print('There were no grades to remove for student')
                        print("Student Removed")
                    except ValueError:
                        print('Entered value is not a valid number')
                    except MissingIdError as e:
                        print(e)
                else:
                    print('List of disciplines')
                    self.list_students_disciplines(self.discipline_manager.disciplines)
                    read_id = input('Enter Discipline id:')
                    try:
                        read_id = int(read_id)
                        self.discipline_manager.remove_discipline(read_id)
                        try:
                            self.grade_manager.remove_all_discipline_grades(read_id)
                        except KeyError:
                            print('There were no grades to remove for discipline')
                        print("Discipline Removed")
                    except ValueError:
                        print('Entered value is not a valid number')
                    except MissingIdError as e:
                        print(e)
            elif read_input == '3':
                if self.selected_option() == 1:
                    print('List of students')
                    self.list_students_disciplines(self.student_manager.students)
                    read_id = input('Enter Student id:')
                    try:
                        read_id = int(read_id)
                        student = self.student_manager.retrieve_student(read_id)
                        read_name = input('Enter new student Name:')
                        student.name = read_name
                        print("Student Updated")
                    except ValueError:
                        print('Entered value is not a valid number')
                    except MissingIdError as e:
                        print(e)
                else:
                    print('List of disciplines')
                    self.list_students_disciplines(self.discipline_manager.disciplines)
                    read_id = input('Enter Discipline id:')
                    try:
                        read_id = int(read_id)
                        discipline = self.discipline_manager.remove_discipline(read_id)
                        read_name = input("Enter new discipline Name:")
                        discipline.name = read_name
                        print("Discipline Updated")
                    except ValueError:
                        print('Entered value is not a valid number')
                    except MissingIdError as e:
                        print(e)
            elif read_input == '4':
                if self.selected_option() == 1:
                    self.list_students_disciplines(self.student_manager.students)
                else:
                    self.list_students_disciplines(self.discipline_manager.disciplines)
            elif read_input == '5':
                try:
                    print('List of students:')
                    self.list_students_disciplines(self.student_manager.students)
                    read_student_id = input('Enter Student id:')
                    read_student_id = int(read_student_id)
                    print('List of disciplines:')
                    self.list_students_disciplines(self.discipline_manager.disciplines)
                    read_discipline_id = input('Enter Student id:')
                    read_discipline_id = int(read_discipline_id)
                    read_grade_value = input('Enter Student grade:')
                    read_grade_value = float(read_grade_value)
                    grade = Grade(read_discipline_id, read_student_id, read_grade_value)
                    self.grade_manager.add_grade(grade)
                    print('Grade added!')
                except ValueError:
                    print('Entered value is not a valid number')
                except MissingIdError as e:
                    print(e)
            elif read_input == '6':
                if self.selected_option() == 1:
                    print('List of students:')
                    self.list_students_disciplines(self.student_manager.students)
                    read_id = input('Enter Student Id: ')
                    try:
                        read_id = int(read_id)
                        self.print_grades(self.grade_manager.get_student_grades(read_id))
                    except ValueError:
                        print('Entered value is not a number!')
                    except KeyError:
                        print('Student with id is not graded yet')
                else:
                    print('List of disciplines:')
                    self.list_students_disciplines(self.discipline_manager.disciplines)
                    read_id = input('Enter Discipline Id: ')
                    try:
                        read_id = int(read_id)
                        self.print_grades(self.grade_manager.get_discipline_grades(read_id))
                    except ValueError:
                        print('Entered value is not a number!')
                    except KeyError:
                        print('Discipline with id is not graded yet')

    def read_student(self):
        read_name = input("Enter student name: ")
        return Student(self.student_manager.last_student_id + 1, read_name)

    def read_discipline(self):
        read_name = input("Enter discipline name: ")
        return Discipline(self.discipline_manager.last_discipline_id + 1, read_name)

    def list_students_disciplines(self, elements: List[Union[Student, Discipline]]):
        for element in elements:
            print('{}. {}'.format(element.id, element.name))
        print('')

    def print_grades(self, grades: List[Grade]):
        if len(grades) == 0:
            print('There are no grades')
        for grade in grades:
            student = self.student_manager.retrieve_student(grade.student_id)
            discipline = self.discipline_manager.retrieve_discipline(grade.discipline_id)
            print('{}. {}, {}. {}, {}'.format(discipline.id, discipline.name, student.id, student.name,
                                              grade.grade_value))
