class DuplicateIdError(Exception):
    pass


class MissingIdError(Exception):
    pass


class RepositoryError(Exception):
    pass
