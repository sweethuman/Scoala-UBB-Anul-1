from unittest import TestCase


class TestRanking(TestCase):
    def test_contestants(self):
        self.fail()

    def test_ranking(self):
        self.fail()

    def test_add_contestant(self):
        self.fail()

    def test_insert_contestant(self):
        self.fail()

    def test_remove_contestant(self):
        self.fail()

    def test_remove_contestant_start_to_end(self):
        self.fail()

    def test_replace_problem_score(self):
        self.fail()


class TestUndoableRanking(TestCase):
    def test_add_contestant(self):
        self.fail()

    def test_insert_contestant(self):
        self.fail()

    def test_remove_contestant(self):
        self.fail()

    def test_remove_contestant_start_to_end(self):
        self.fail()

    def test_replace_problem_score(self):
        self.fail()

    def test_undo(self):
        self.fail()
