class OutputColors:
    HEADER = '\033[95m'  # Light Magenta
    OKBLUE = '\033[94m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'  # Light Yellow
    FAIL = '\033[91m'  # Light Red
    ENDC = '\033[0m'  # Ends Color
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
